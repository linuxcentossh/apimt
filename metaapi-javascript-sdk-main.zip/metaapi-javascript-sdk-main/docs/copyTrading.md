## CopyFactory copy trading API

CopyFactory is a powerful trade copying API which makes developing forex
trade copying applications as easy as writing few lines of code.

You can find CopyFactory Javascript SDK documentation here: [https://github.com/metaapi/metaapi-copyfactory-javascript-sdk](https://github.com/metaapi/metaapi-copyfactory-javascript-sdk)
