## MetaApi MT manager API

MetaApi MT manager API is a cloud REST API which can be used to access and manage MT4 and MT5 servers.

You can find MT manager API documentation here: [https://metaapi.cloud/docs/manager/](https://metaapi.cloud/docs/manager/)
