## MetaStats trading statistics API

MetaStats is a powerful trade statistics API which makes it possible to add forex trading metrics into forex applications.

You can find MetaStats Javascript SDK documentation here: [https://github.com/metaapi/metaapi-metastats-javascript-sdk](https://github.com/metaapi/metaapi-metastats-javascript-sdk)
