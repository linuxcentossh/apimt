import StreamQuotes from './steamQuotes.vue';

export {
    StreamQuotes
}