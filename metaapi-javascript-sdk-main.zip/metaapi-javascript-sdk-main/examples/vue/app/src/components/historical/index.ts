import HistoricalGetCandles from './getCandles.vue';
import HistoricalGetTicks from './getTicks.vue';

export {
  HistoricalGetCandles,
  HistoricalGetTicks,
}