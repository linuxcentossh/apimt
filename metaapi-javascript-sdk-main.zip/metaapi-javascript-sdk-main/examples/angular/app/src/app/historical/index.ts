export * from './getCandles/getCandles.component';
export * from './getTicks/getTicks.component';
